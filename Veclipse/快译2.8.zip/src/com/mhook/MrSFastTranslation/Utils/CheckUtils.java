package com.mhook.MrSFastTranslation.Utils;
import android.os.*;
import android.content.*;
import android.app.*;
import android.content.pm.*;
import java.lang.reflect.*;

public class CheckUtils
{
	
	
}
